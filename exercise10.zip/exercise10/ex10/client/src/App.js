import "./App.css";
import WeatherView from "./WeatherView";

function App() {
  return (
    <div className="App">
      <WeatherView />
    </div>
  );
}

export default App;
